# Derin Öğrenme CIFAR-10 Projesi
